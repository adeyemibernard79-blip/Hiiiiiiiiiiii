package com.nexora.play.data

import android.content.Context
import androidx.datastore.preferences.core.*
import androidx.datastore.preferences.preferencesDataStore

val Context.dataStore by preferencesDataStore("settings")

object Keys {
    val ROM_URI = stringPreferencesKey("rom_uri")
    val QUALITY = stringPreferencesKey("quality")
    val FPS = intPreferencesKey("fps")
    val PAD_OPACITY = floatPreferencesKey("pad_opacity")
}

data class Settings(
    val romUri: String? = null,
    val quality: String = "720p",
    val fps: Int = 60,
    val padOpacity: Float = 0.6f,
)

fun Preferences.toSettings() = Settings(
    romUri = this[Keys.ROM_URI],
    quality = this[Keys.QUALITY] ?: "720p",
    fps = this[Keys.FPS] ?: 60,
    padOpacity = this[Keys.PAD_OPACITY] ?: 0.6f,
)

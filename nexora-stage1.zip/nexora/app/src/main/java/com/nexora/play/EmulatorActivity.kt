package com.nexora.play

import android.content.Context
import android.content.Intent
import android.net.Uri
import android.os.Bundle
import android.view.InputDevice
import android.view.KeyEvent
import android.view.MotionEvent
import android.view.WindowManager
import android.widget.Toast
import androidx.activity.ComponentActivity
import androidx.activity.compose.BackHandler
import androidx.activity.compose.setContent
import androidx.activity.enableEdgeToEdge
import androidx.compose.foundation.background
import androidx.compose.foundation.layout.*
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.Alignment
import androidx.compose.ui.Modifier
import androidx.compose.ui.graphics.Color
import androidx.compose.ui.unit.dp
import androidx.compose.ui.viewinterop.AndroidView
import androidx.core.view.WindowCompat
import androidx.core.view.WindowInsetsCompat
import androidx.core.view.WindowInsetsControllerCompat
import androidx.lifecycle.lifecycleScope
import com.nexora.play.data.Game
import com.nexora.play.data.GameSystem
import com.nexora.play.ui.Gamepad
import com.nexora.play.ui.NexoraTheme
import com.swordfish.libretrodroid.GLRetroView
import com.swordfish.libretrodroid.GLRetroViewData
import com.swordfish.libretrodroid.Variable
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File
import java.util.zip.ZipInputStream

class EmulatorActivity : ComponentActivity() {

    sealed interface Phase {
        data object Preparing : Phase
        data class Ready(val view: GLRetroView) : Phase
        data class Error(val msg: String) : Phase
    }

    private var retro: GLRetroView? = null
    private var sramFile: File? = null
    private var stateFile: File? = null
    private val phase = mutableStateOf<Phase>(Phase.Preparing)
    private lateinit var system: GameSystem
    private var opacity = 0.6f

    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        enableEdgeToEdge()
        WindowInsetsControllerCompat(window, window.decorView).let {
            it.hide(WindowInsetsCompat.Type.systemBars())
            it.systemBarsBehavior = WindowInsetsControllerCompat.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE
        }
        window.addFlags(WindowManager.LayoutParams.FLAG_KEEP_SCREEN_ON)

        val title = intent.getStringExtra(X_TITLE) ?: "Game"
        system = runCatching { GameSystem.valueOf(intent.getStringExtra(X_SYSTEM) ?: "") }.getOrNull() ?: GameSystem.PSP
        val uri = Uri.parse(intent.getStringExtra(X_URI) ?: "")
        val fileName = File(intent.getStringExtra(X_FILE) ?: "game.bin").name
        val extraNames = intent.getStringArrayListExtra(X_EXTRA_NAMES) ?: arrayListOf()
        val extraUris = intent.getStringArrayListExtra(X_EXTRA_URIS) ?: arrayListOf()
        opacity = intent.getFloatExtra(X_OPACITY, 0.6f)
        val key = Integer.toHexString(uri.toString().hashCode())
        stateFile = File(filesDir, "states/$key.state")
        sramFile = File(filesDir, "saves/$key.srm")

        setContent { NexoraTheme { GameScreen(title) } }
        lifecycleScope.launch { prepare(uri, fileName, extraNames.zip(extraUris.map(Uri::parse))) }
    }

    private suspend fun prepare(uri: Uri, fileName: String, extras: List<Pair<String, Uri>>) {
        try {
            val data = withContext(Dispatchers.IO) {
                val dir = File(cacheDir, "rom").apply { deleteRecursively(); mkdirs() }
                fun copy(name: String, u: Uri) {
                    val input = contentResolver.openInputStream(u) ?: error("Cannot open $name")
                    input.use { i -> File(dir, File(name).name).outputStream().use { o -> i.copyTo(o, 1 shl 16) } }
                }
                copy(fileName, uri)
                extras.forEach { (n, u) -> copy(n, u) }
                val sys = File(filesDir, "system").apply { mkdirs() }
                val saves = File(filesDir, "saves").apply { mkdirs() }
                File(filesDir, "states").mkdirs()
                if (system == GameSystem.PSP) ensurePspFiles(sys)
                val sram = sramFile
                GLRetroViewData(this@EmulatorActivity).apply {
                    coreFilePath = system.coreLib
                    gameFilePath = File(dir, fileName).absolutePath
                    systemDirectory = sys.absolutePath
                    savesDirectory = saves.absolutePath
                    saveRAMState = if (sram != null && sram.exists()) sram.readBytes() else null
                    if (system == GameSystem.PSP) {
                        // Native PSP resolution: the best balance for a Helio G81.
                        variables = arrayOf(Variable("ppsspp_internal_resolution", "480x272"))
                    }
                }
            }
            val view = GLRetroView(this, data)
            lifecycle.addObserver(view)
            retro = view
            phase.value = Phase.Ready(view)
        } catch (t: Throwable) {
            phase.value = Phase.Error(t.message ?: t.javaClass.simpleName)
        }
    }

    private fun ensurePspFiles(sys: File) {
        if (File(sys, "PPSSPP/ppge_atlas.zim").exists()) return
        assets.open("PPSSPP.zip").use { raw ->
            ZipInputStream(raw).use { zip ->
                var e = zip.nextEntry
                while (e != null) {
                    val rel = if (e.name.startsWith("PPSSPP/")) e.name else "PPSSPP/${e.name}"
                    val out = File(sys, rel)
                    if (out.canonicalPath.startsWith(sys.canonicalPath)) {
                        if (e.isDirectory) out.mkdirs() else {
                            out.parentFile?.mkdirs()
                            out.outputStream().use { zip.copyTo(it) }
                        }
                    }
                    e = zip.nextEntry
                }
            }
        }
    }

    // SRAM / memory cards must be saved by the app. Written synchronously so exit can't lose it.
    private fun persistSram() {
        val v = retro ?: return
        val f = sramFile ?: return
        lifecycleScope.launch {
            runCatching { f.parentFile?.mkdirs(); f.writeBytes(v.serializeSRAM()) }
        }
    }

    override fun onStop() { persistSram(); super.onStop() }

    override fun onDestroy() {
        File(cacheDir, "rom").deleteRecursively()
        super.onDestroy()
    }

    private fun saveState(view: GLRetroView) = lifecycleScope.launch {
        val f = stateFile ?: return@launch
        runCatching {
            val bytes = view.serializeState()
            withContext(Dispatchers.IO) { f.parentFile?.mkdirs(); f.writeBytes(bytes) }
        }.onSuccess { toast("State saved") }.onFailure { toast("Save failed: ${it.message}") }
    }

    private fun loadState(view: GLRetroView) = lifecycleScope.launch {
        val f = stateFile
        if (f == null || !f.exists()) { toast("No saved state yet"); return@launch }
        runCatching {
            val bytes = withContext(Dispatchers.IO) { f.readBytes() }
            view.unserializeState(bytes)
        }.onSuccess { toast("State loaded") }.onFailure { toast("Load failed: ${it.message}") }
    }

    private fun toast(s: String) = Toast.makeText(this, s, Toast.LENGTH_SHORT).show()

    // External controllers
    override fun dispatchKeyEvent(event: KeyEvent): Boolean {
        val v = retro
        val s = event.source
        val pad = (s and InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
            (s and InputDevice.SOURCE_DPAD) == InputDevice.SOURCE_DPAD
        if (v != null && pad && event.keyCode != KeyEvent.KEYCODE_BACK) {
            v.sendKeyEvent(event.action, event.keyCode, 0)
            return true
        }
        return super.dispatchKeyEvent(event)
    }

    override fun onGenericMotionEvent(e: MotionEvent): Boolean {
        val v = retro
        if (v != null && (e.source and InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK &&
            e.action == MotionEvent.ACTION_MOVE
        ) {
            v.sendMotionEvent(GLRetroView.MOTION_SOURCE_DPAD, e.getAxisValue(MotionEvent.AXIS_HAT_X), e.getAxisValue(MotionEvent.AXIS_HAT_Y), 0)
            v.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, e.getAxisValue(MotionEvent.AXIS_X), e.getAxisValue(MotionEvent.AXIS_Y), 0)
            v.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_RIGHT, e.getAxisValue(MotionEvent.AXIS_Z), e.getAxisValue(MotionEvent.AXIS_RZ), 0)
            return true
        }
        return super.onGenericMotionEvent(e)
    }

    @Composable
    private fun GameScreen(title: String) {
        val p by phase
        BackHandler { finish() }
        Box(Modifier.fillMaxSize().background(Color.Black)) {
            when (val s = p) {
                Phase.Preparing -> Column(Modifier.align(Alignment.Center), horizontalAlignment = Alignment.CenterHorizontally) {
                    CircularProgressIndicator()
                    Spacer(Modifier.height(12.dp))
                    Text("Preparing $title\u2026", color = Color.White)
                }
                is Phase.Error -> Column(Modifier.align(Alignment.Center).padding(24.dp), horizontalAlignment = Alignment.CenterHorizontally) {
                    Text("Couldn't start the game", color = Color.White, style = MaterialTheme.typography.titleMedium)
                    Spacer(Modifier.height(8.dp))
                    Text(s.msg, color = Color.White.copy(alpha = 0.7f))
                    Spacer(Modifier.height(12.dp))
                    Button(onClick = { finish() }) { Text("Back") }
                }
                is Phase.Ready -> {
                    AndroidView(factory = { s.view }, modifier = Modifier.fillMaxSize())
                    Gamepad(
                        system = system, opacity = opacity,
                        key = { code, down -> s.view.sendKeyEvent(if (down) KeyEvent.ACTION_DOWN else KeyEvent.ACTION_UP, code, 0) },
                        stick = { x, y -> s.view.sendMotionEvent(GLRetroView.MOTION_SOURCE_ANALOG_LEFT, x, y, 0) },
                    )
                    Row(
                        Modifier.align(Alignment.TopCenter).statusBarsPadding().padding(top = 6.dp),
                        horizontalArrangement = Arrangement.spacedBy(8.dp),
                    ) {
                        OutlinedButton(onClick = { persistSram(); finish() }) { Text("Exit") }
                        OutlinedButton(onClick = { saveState(s.view) }) { Text("Save") }
                        OutlinedButton(onClick = { loadState(s.view) }) { Text("Load") }
                    }
                }
            }
        }
    }

    companion object {
        private const val X_TITLE = "title"
        private const val X_SYSTEM = "system"
        private const val X_URI = "uri"
        private const val X_FILE = "file"
        private const val X_EXTRA_NAMES = "extraNames"
        private const val X_EXTRA_URIS = "extraUris"
        private const val X_OPACITY = "opacity"

        fun launch(ctx: Context, g: Game, opacity: Float) {
            ctx.startActivity(
                Intent(ctx, EmulatorActivity::class.java)
                    .putExtra(X_TITLE, g.title)
                    .putExtra(X_SYSTEM, g.system.name)
                    .putExtra(X_URI, g.uri.toString())
                    .putExtra(X_FILE, g.fileName)
                    .putStringArrayListExtra(X_EXTRA_NAMES, ArrayList(g.extras.map { it.first }))
                    .putStringArrayListExtra(X_EXTRA_URIS, ArrayList(g.extras.map { it.second.toString() }))
                    .putExtra(X_OPACITY, opacity)
            )
        }
    }
}

package com.nexora.play.data

import android.content.Context
import android.net.Uri
import androidx.documentfile.provider.DocumentFile

/** face = labels for [bottom, right, left, top] buttons. */
enum class GameSystem(
    val label: String,
    val exts: Set<String>,
    val coreLib: String,
    val face: List<String>,
    val hasAnalog: Boolean,
    val hasL2R2: Boolean,
) {
    PSP("PSP", setOf("cso", "pbp", "iso"), "libppsspp_libretro_android.so",
        listOf("\u2715", "\u25CB", "\u25A1", "\u25B3"), true, false),
    PS1("PlayStation", setOf("cue", "chd"), "libpcsx_rearmed_libretro_android.so",
        listOf("\u2715", "\u25CB", "\u25A1", "\u25B3"), false, true),
    NDS("Nintendo DS", setOf("nds"), "libdesmume_libretro_android.so",
        listOf("B", "A", "Y", "X"), false, false),
}

data class Game(
    val title: String,
    val uri: Uri,
    val system: GameSystem,
    val sizeBytes: Long,
    val fileName: String,
    /** Extra files that must sit next to the main file (the .bin tracks of a .cue). */
    val extras: List<Pair<String, Uri>> = emptyList(),
)

object RomScanner {
    fun scan(ctx: Context, tree: Uri): List<Game> {
        val root = DocumentFile.fromTreeUri(ctx, tree) ?: return emptyList()
        val out = mutableListOf<Game>()
        walk(ctx, root, out, 0)
        return out.sortedBy { it.title.lowercase() }
    }

    private fun walk(ctx: Context, dir: DocumentFile, out: MutableList<Game>, depth: Int) {
        if (depth > 4) return
        val files = dir.listFiles()
        val byName = files.filter { it.isFile }.mapNotNull { f -> f.name?.let { it to f } }.toMap()
        for (f in files) {
            if (f.isDirectory) { walk(ctx, f, out, depth + 1); continue }
            val name = f.name ?: continue
            val ext = name.substringAfterLast('.', "").lowercase()
            val sys = GameSystem.values().firstOrNull { ext in it.exts } ?: continue
            var size = f.length()
            val extras = mutableListOf<Pair<String, Uri>>()
            if (ext == "cue") {
                for (ref in cueReferences(ctx, f.uri)) {
                    val t = byName[ref] ?: continue
                    extras += ref to t.uri
                    size += t.length()
                }
            }
            out += Game(name.substringBeforeLast('.'), f.uri, sys, size, name, extras)
        }
    }

    private fun cueReferences(ctx: Context, uri: Uri): List<String> = runCatching {
        val text = ctx.contentResolver.openInputStream(uri)!!.use { it.readBytes().take(64 * 1024).toByteArray().decodeToString() }
        Regex("FILE\\s+\"([^\"]+)\"", RegexOption.IGNORE_CASE).findAll(text).map { it.groupValues[1] }.toList()
    }.getOrDefault(emptyList())
}

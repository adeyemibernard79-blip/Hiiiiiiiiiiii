package com.nexora.play.ui

import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.Composable
import androidx.compose.runtime.getValue
import androidx.compose.ui.Modifier
import androidx.compose.ui.text.font.FontWeight
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexora.play.AppViewModel
import com.nexora.play.data.GameSystem

@Composable
fun HomeScreen(vm: AppViewModel, open: (Tab) -> Unit) {
    val games by vm.games.collectAsStateWithLifecycle()
    LazyColumn(contentPadding = PaddingValues(20.dp), verticalArrangement = Arrangement.spacedBy(16.dp)) {
        item {
            Text("Nexora", style = MaterialTheme.typography.headlineLarge, fontWeight = FontWeight.Bold)
            Text("Your games, your way.", color = Cyan)
        }
        item {
            Column(Modifier.fillMaxWidth().glass().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Emulator library", style = MaterialTheme.typography.titleLarge)
                Text(if (games.isEmpty()) "No games found yet. Pick the folder that holds your ROMs."
                     else "${games.size} games found on this device.")
                Button(onClick = { open(Tab.Library) }) { Text("Open library") }
            }
        }
        item { Text("By system", style = MaterialTheme.typography.titleMedium) }
        items(GameSystem.values().toList()) { s ->
            Row(Modifier.fillMaxWidth().glass().padding(16.dp), horizontalArrangement = Arrangement.SpaceBetween) {
                Text(s.label)
                Text("${games.count { it.system == s }}", color = Cyan)
            }
        }
        item {
            Column(Modifier.fillMaxWidth().glass().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Cloud streaming", style = MaterialTheme.typography.titleLarge)
                Text("Not set up. No server is connected, so nothing is shown as available.")
                OutlinedButton(onClick = { open(Tab.Cloud) }) { Text("Details") }
            }
        }
    }
}

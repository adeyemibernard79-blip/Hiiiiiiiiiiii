package com.nexora.play.ui

import androidx.activity.compose.rememberLauncherForActivityResult
import androidx.activity.result.contract.ActivityResultContracts
import androidx.compose.foundation.layout.*
import androidx.compose.foundation.lazy.LazyColumn
import androidx.compose.foundation.lazy.items
import androidx.compose.material3.*
import androidx.compose.runtime.*
import androidx.compose.ui.platform.LocalContext
import com.nexora.play.EmulatorActivity
import androidx.compose.ui.Modifier
import androidx.compose.ui.unit.dp
import androidx.lifecycle.compose.collectAsStateWithLifecycle
import com.nexora.play.AppViewModel
import com.nexora.play.data.GameSystem

@Composable
fun LibraryScreen(vm: AppViewModel) {
    val games by vm.games.collectAsStateWithLifecycle()
    val settings by vm.settings.collectAsStateWithLifecycle()
    val scanning by vm.scanning.collectAsStateWithLifecycle()
    val ctx = LocalContext.current
    var query by remember { mutableStateOf("") }
    var filter by remember { mutableStateOf<GameSystem?>(null) }
    val picker = rememberLauncherForActivityResult(ActivityResultContracts.OpenDocumentTree()) { it?.let(vm::setRomFolder) }

    Column(Modifier.fillMaxSize().padding(20.dp), verticalArrangement = Arrangement.spacedBy(12.dp)) {
        Text("Library", style = MaterialTheme.typography.headlineMedium)
        if (settings.romUri == null) {
            Column(Modifier.fillMaxWidth().glass().padding(20.dp), verticalArrangement = Arrangement.spacedBy(8.dp)) {
                Text("Choose the folder that contains your game files (PSP, PS1, DS). Only files you provide are used.")
                Button(onClick = { picker.launch(null) }) { Text("Choose ROM folder") }
            }
            return@Column
        }
        OutlinedTextField(query, { query = it }, Modifier.fillMaxWidth(), singleLine = true, label = { Text("Search") })
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            FilterChip(filter == null, { filter = null }, { Text("All") })
            GameSystem.values().forEach { s -> FilterChip(filter == s, { filter = if (filter == s) null else s }, { Text(s.label) }) }
        }
        Row(horizontalArrangement = Arrangement.spacedBy(8.dp)) {
            OutlinedButton(onClick = vm::rescan, enabled = !scanning) { Text(if (scanning) "Scanning…" else "Rescan") }
            OutlinedButton(onClick = { picker.launch(null) }) { Text("Change folder") }
        }
        val shown = games.filter { (filter == null || it.system == filter) && it.title.contains(query, ignoreCase = true) }
        Text("${shown.size} games", color = Cyan)
        LazyColumn(verticalArrangement = Arrangement.spacedBy(10.dp)) {
            items(shown, key = { it.uri.toString() }) { g ->
                Row(Modifier.fillMaxWidth().glass().padding(16.dp), verticalAlignment = androidx.compose.ui.Alignment.CenterVertically) {
                    Column(Modifier.weight(1f)) {
                        Text(g.title, style = MaterialTheme.typography.titleMedium)
                        Text("${g.system.label} \u2022 ${g.sizeBytes / (1024 * 1024)} MB", color = Cyan)
                    }
                    Button(onClick = { EmulatorActivity.launch(ctx, g, settings.padOpacity) }) { Text("Play") }
                }
            }
        }
    }
}
